import java.lang.*;
import java.util.*;
public class Start{
	public static void main(String[] args)
	{
		System.out.println("                E-commerce Management System.");
		int op=1;
		System.out.println("1. Regester.");
		System.out.println("2. Login.");
		
		
		Scanner sc = new Scanner(System.in);
		Regester reg = new Regester();
		do{
			System.out.println("Enter your Entity.");
			op=sc.nextInt();
			switch(op)
			{
				case 1: reg.getRegestration();
				reg.showRegInfo();
				break;
				case 2: reg.getLogin();
				
				break;
				
				
				default: System.out.println("Invalid! Please Regestrater your account.");
				break;
			}
		}while(op!=2);
		
			
		
		
		
		
		
		System.out.println("                Welcome to E-commerce Management System.");
		System.out.println("\n");
		Managemant manage = new Managemant("Mohammmad",2);
		manage.ShowDetails();
		Customer cus1 = new Customer();
		Employee emp1 = new Employee();
		Quantity pro1 = new Quantity("Chair","44583","X","Medium",250,20);
		Quantity pro2 = new Quantity("Table","44532","Steel","Hard",500,25);
		
		
		Contact cont = new Contact("www.e-commerce.com","e-commerce123@gmail.com","01810001500");
		
		int option=1;
		do{
			System.out.println("Enter your Entity.");
			option=sc.nextInt();
			switch(option)
			{
				case 1: cus1.getCustomer();
				cus1.showInfo();
				break;
				case 2: emp1.getEmployee();
				emp1.showInfo();
				break;
				case 3: pro1.ShowInfo();
				System.out.println("Quantity:"+pro1.getAvailableQuantity());
				pro2.ShowInfo();
				System.out.println("Quantity:"+pro2.getAvailableQuantity());
				
				break;
				case 4: manage.OrderProduct(pro1);
				break;
				case 5: manage.SearchProduct("Chair");
				break;
				case 6: System.out.println("Product 1 quntity:"+pro1.getAvailableQuantity());
				pro1.AddProductQuantity();
				System.out.println("After added:"+pro1.getAvailableQuantity());
				System.out.println("Product 2 quntity:"+pro2.getAvailableQuantity());
				pro2.AddProductQuantity();
				System.out.println("After added:"+pro2.getAvailableQuantity());
				
				break;
				case 7: manage.RemoveProduct(pro2);
				manage.showAllProductDetails();
				break;
				case 8: pro1.SalesProduct();
				System.out.println("After Sales this product quantity:"+pro1.getAvailableQuantity());
				pro2.SalesProduct();
				System.out.println("After Sales this product quantity:"+pro2.getAvailableQuantity());
				
				break;
				case 9: cont.ShowInfo();
				break;
				case 10: System.out.println(" ");
				break;
				default: System.out.println("Invalid! Please try again");
			}
		}while(option!=10);
		System.out.println("Thank you for visiting our System Managemant.");
	}
}	
		
		
		
public class Product{
	private String pro_Name;
	private String pro_Id;
	private String pro_Type;
	private String pro_Category;
	private double pro_Price;
	
	public Product()
	{
		System.out.println(" ");
	}
	public Product(String pro_Name,String pro_Id,String  pro_Type,String pro_Category,double pro_Price)
	{
		this.pro_Name=pro_Name;
		this.pro_Id=pro_Id;
		this.pro_Type=pro_Type;
		this.pro_Category=pro_Category;
		this.pro_Price=pro_Price;
	}
	public void setProdName(String pro_Name)
	{
		this.pro_Name=pro_Name;
	}
	public String getProdName()
	{
		return pro_Name;
	}
	public void setProdId(String pro_Id)
	{
		this.pro_Id=pro_Id;
	}
	public String getProdId()
	{
		return pro_Id;
	}
	public void setProdType(String pro_Type)
	{
		this.pro_Type=pro_Type;
	}
	public String getProudType()
	{
		return pro_Type;
	}
	public void setProdCategory(String pro_Category)
	{
		this.pro_Category=pro_Category;
	}
	public String getProdCategory()
	{
		return pro_Category;
	}
	public void setProdPrice(double pro_Price)
	{
		this.pro_Price=pro_Price;
	}
	public double getProdPrice()
	{
		return pro_Price;
	}
	public void ShowInfo()
	{
		System.out.println("product Name:"+pro_Name);
		System.out.println("product Id:"+pro_Id);
		System.out.println("product Type:"+pro_Type);
		System.out.println("product category:"+pro_Category);
		System.out.println("product Price:"+pro_Price);
	}
}
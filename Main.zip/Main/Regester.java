import java.lang.*;
import java.util.*;
public class Regester{
	String FName;
	String LName;
	String Email;
	String Pass;
	Scanner sc = new Scanner(System.in);
	
	public void getRegestration()
	{
		System.out.println("Enter First Name");
		FName=sc.nextLine();
		System.out.println("Enter Last Name");
		LName=sc.nextLine();
		System.out.println("Email/phone");
		Email=sc.nextLine();
		System.out.println("Password");
		Pass=sc.nextLine();
	}
	public void showRegInfo()
	{
		if(FName!=null)
		{
			if(LName!=null)
			{
				if(Email!=null)
				{
					if(Pass!=null)
					{
						System.out.println("Regestration Complete.");
					}
				}
			}
		}
		else {
			System.out.println("Sorry.You are not Regestered");
		}
	}
	public void getLogin()
	{
		System.out.println("Email/phone");
		Email=sc.nextLine();
		System.out.println("Password");
		Pass=sc.nextLine();
		if(Email.equals(Email) && Pass.equals(Pass))
			
		{
			System.out.println(" ");
				
		}
		else { System.out.println("Error");}
			
	}
	
}
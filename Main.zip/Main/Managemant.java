import java.lang.*;
//import java.util.*;
public class Managemant{
	private String manager;
	Product product[];
	
	public Managemant()
	{
		System.out.println(" ");
	}
	public Managemant(String manager,int psize)
	{
		this.manager=manager;
		product = new Product[psize];
	}
	public void setManager(String manager)
	{
		this.manager=manager;
	}
	public String getManager()
	{
		return manager;
	}
	public void OrderProduct(Product p)
	{
		int Order=0;
		for(int i=0;i<product.length;i++)
		{
			if(product[i]==null)
			{
				product[i]=p;
				Order=1;
				break;
			}
		}
		if(Order==0)
		{
			System.out.println("Product could not be ordered");
		}
		else{
			System.out.println("Your product could be ordered");
		}
	}
	Product SearchProduct(String pro_Name)
	{
		int F=0;
		int S=0;
		for(int i=0;i<product.length;i++)
		{
			if(product[i]!=null)
			{
				if(product[i].getProdName().equals(pro_Name))
				{
					F=1;
					S=i;
				}
			}
		}
		if(F==0)
		{
			System.out.println("Product could not be exist");
		}
		else {
			System.out.println("Product could be exist");
			
			
		} return null;
	}
	public void RemoveProduct(Product P)
	{
		int R=0;
		for(int i=0;i<product.length;i++)
		{
			if(product[i]==P)
			{
				product[i]=null;
				R=1;
				break;
			}
		}
		if(R==0)
		{
			System.out.println("This product removed");
		}
		else {
			System.out.println("This product doesn't removed ");
		}
	}
	public void showAllProductDetails()
	{
		for(int i=0;i<product.length;i++)
		{
			if(product[i]!=null)
			{
				product[i].ShowInfo();
			}
		}
	}
	
	
		
		
	public void ShowDetails()
	{
		int option=0;
		System.out.println("1. Customer Details.");
		System.out.println("2. Employee Details.");
		System.out.println("3. Product Details.");
		System.out.println("4. Order Product.");
		System.out.println("5. Search Product.");
		System.out.println("6. Add Product.");
		System.out.println("7. Remove Product.");
		System.out.println("8. Sales Product.");
		System.out.println("9. Contact.");
		System.out.println("10. Logout.");
	}
}
				
	
	
import java.lang.*;
import java.util.*;
public class Employee extends Service{
   String Emp_name;
   String Emp_id;
   String Emp_salary;
   String Emp_mobnumber;
   Scanner sc = new Scanner(System.in);
   public void getEmployee()
   {
	   System.out.println("Enter Employee Name");
	   Emp_name=sc.nextLine();
	   System.out.println("Enter Employee Id");
	   Emp_id=sc.nextLine();
	   System.out.println("Enter Employee Salary");
	   Emp_salary=sc.nextLine();
	   System.out.println("Enter Cell Number");
	   Emp_mobnumber=sc.nextLine();
   }
   public void showInfo()
   {
	   System.out.println("Employee Name:"+Emp_name);
	   System.out.println("Employee Id:"+Emp_id);
	   System.out.println("Salary:"+Emp_salary);
	   System.out.println("Contact:"+Emp_mobnumber);
   }
}
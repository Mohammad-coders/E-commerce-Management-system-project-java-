interface Iinfo{
	void ShowInfo();
}
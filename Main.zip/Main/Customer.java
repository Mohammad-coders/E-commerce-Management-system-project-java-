import java.lang.*;
import java.util.*;
public class Customer extends Service{
	String cus_name;
	int cus_Id;
	Scanner sc = new Scanner(System.in);
	
	public void getCustomer()
	{
		System.out.println("Enter customer name");
		cus_name=sc.nextLine();
		System.out.println("Enter cutomer id");
		cus_Id=sc.nextInt();
	}
	public void showInfo()
	{
		System.out.println("Customer Name:"+cus_name);
		System.out.println("Customer id:"+cus_Id);
	}
}